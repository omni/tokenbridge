#!/usr/bin/env bash

source ./scripts/version/version.sh

compare_versions $1
