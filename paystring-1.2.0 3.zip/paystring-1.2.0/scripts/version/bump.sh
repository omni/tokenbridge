#!/usr/bin/env bash

source ./scripts/version/version.sh

bump $1 $2
