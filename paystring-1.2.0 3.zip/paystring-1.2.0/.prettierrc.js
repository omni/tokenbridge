module.exports = {
    tabWidth: 2,
    printWidth: 80,
    singleQuote: true,
    semi: false,
    trailingComma: 'all',
    arrowParens: 'always',
}
