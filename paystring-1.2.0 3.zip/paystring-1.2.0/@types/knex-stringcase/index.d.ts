declare module 'knex-stringcase'
